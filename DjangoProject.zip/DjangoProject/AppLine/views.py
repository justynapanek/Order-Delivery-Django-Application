from django.shortcuts import render
from django.db import connection
from django.http import JsonResponse

from .models import *

# Create your views here.


def index(request):
	context = {
	"items": Item.objects.values_list('i_name', flat=True ).order_by('i_name').distinct(),
	"warehouses": Warehouse.objects.values_list('w_name', flat=True ).order_by('w_name').distinct()
	}
	return render(request, 'AppLine/index.html', context)
		
def request_form(request):
	search_string_i = request.GET.get('search_i','')
	search_string_w = request.GET.get('search_w','')

	result_i = Item.objects.filter(i_name__regex = r'%s' %(search_string_i))
	result_w = Warehouse.objects.filter(w_name__regex = r'%s' %(search_string_w))

	records_i = [(r.i_id, r.i_im_id, r.i_name, r.i_price) for r in result_i]
	records_w = [(r.w_id, r.w_name, r.w_street, r.w_city, r.w_country) for r in result_w]


	return_dict = {'records_i':records_i,
	'records_w':records_w, 
	"request_types": ['order','delivery']
	}

	return render(request,'AppLine/request_form.html',return_dict)


def result00(request):

	search_type = request.GET.get('type')

	item_id = request.GET.get('item_id')
	warehouse_id= request.GET.get('warehouse_id')

	search_quantity = request.GET.get('quantity')
	search_quantity=int(search_quantity)


	search_item=Item.objects.filter(i_id=item_id).values_list('i_name', flat=True)[0]
	search_warehouse=Warehouse.objects.filter(w_id=warehouse_id).values_list('w_name', flat=True)[0]


	if search_type=='order':
		try:  
			result=Stock.objects.filter(w_id=warehouse_id).filter(i_id=item_id).values_list('s_qty', flat=True)[0]
		except IndexError:
			item_in_stock=Stock.objects.filter(i_id=item_id).values_list('w_id')
			item_in_stock= Warehouse.objects.filter(w_id__in=(item_in_stock))
			records_w = [(r.w_id, r.w_name, r.w_street, r.w_city, r.w_country) for r in item_in_stock]
			result_dict = {'search_item': search_item,'search_warehouse':search_warehouse,'records_w':records_w }
			return render(request, 'AppLine/result_order_fail1.html', result_dict)
		else: 
			if search_quantity<=result:
				result = Stock.objects.filter(w_id=warehouse_id).filter(i_id=item_id).update(s_qty=result -search_quantity)
				result= Stock.objects.filter(i=item_id).filter(w=warehouse_id).values_list('s_qty', flat=True)[0]
				if result==0:
					result = Stock.objects.filter(w_id=warehouse_id).filter(i_id=item_id).delete()
				else:
					pass



				result_dict = {'search_item': search_item,'search_warehouse':search_warehouse,'search_quantity':search_quantity}
				return render(request, 'AppLine/result_order.html',result_dict)
			else:
				item_in_stock=Stock.objects.filter(i_id=item_id).filter(s_qty__gte=search_quantity).values_list('w_id')
				item_in_stock= Warehouse.objects.filter(w_id__in=(item_in_stock))
				records_w = [(r.w_id, r.w_name, r.w_street, r.w_city, r.w_country) for r in item_in_stock]
				quantity_avaiable= Stock.objects.filter(i=item_id).filter(w=warehouse_id).values_list('s_qty', flat=True)[0]
				result_dict = {'search_item': search_item,
					'search_warehouse':search_warehouse,
					'search_quantity':search_quantity,
					'quantity_avaiable':quantity_avaiable,
					'records_w':records_w 
					}				
				return render(request, 'AppLine/result_order_fail2.html', result_dict)
	else:
		try:  
			result= Stock.objects.filter(w_id=warehouse_id).filter(i_id=item_id).values_list('s_qty', flat=True)[0]
		except IndexError:
			result = Stock.objects.get_or_create(w_id= warehouse_id,i_id= item_id, s_qty=search_quantity)
			result_dict = {'search_item': search_item,
			'search_warehouse':search_warehouse,
			'search_quantity':search_quantity
			}
			return render(request, 'AppLine/result_delivery.html', result_dict)
		else: 
			result= Stock.objects.filter(w=warehouse_id).filter(i=item_id).update(s_qty=result+search_quantity)
			result_dict = {'search_item': search_item,
			'search_warehouse':search_warehouse,
			'search_quantity':search_quantity
			}
			return render(request, 'AppLine/result_delivery.html', result_dict)	


		


		


	






		
    	

	






	