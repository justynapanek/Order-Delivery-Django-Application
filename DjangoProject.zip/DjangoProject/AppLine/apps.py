from django.apps import AppConfig


class AppormConfig(AppConfig):
    name = 'AppORM'
